package com.spring.Services;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.*;

import java.util.List;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.spring.model.Disease;
import com.spring.model.Doctor;
import com.spring.model.Medicines;
import com.spring.model.Patient;
import com.spring.repositories.PatientRepo;
import com.spring.services.PatientService;

@SpringBootTest
class PatientServicesTest {

	@Autowired
	private PatientRepo patientrepo;
	
	@Autowired
	private PatientService patientService;

	@Test
	void CreatePatientService()
	{
		
		Medicines med= new Medicines();
		med.setMedicineId(1);
		Disease d= new Disease();
		d.setDiseaseId(1);
		Doctor doc= new Doctor();
		doc.setDoctor_Id(1);
		
		Patient p = new Patient();
		p.setPatientId(1);
		
		p.setMedicationList(med);
		p.setDoctor(doc);
		p.setDisease(d);
		
		assertEquals("Successfully Done", patientService.saveOrUpdate(p));
		
	}
	
	@Test
	void getPatientService()
	{
		Medicines med= new Medicines();
		med.setMedicineId(1);
		Disease d= new Disease();
		d.setDiseaseId(1);
		Doctor doc= new Doctor();
		doc.setDoctor_Id(1);
		
		Patient p = new Patient();
		p.setPatientId(1);
		
		p.setMedicationList(med);
		p.setDoctor(doc);
		p.setDisease(d);
		
		patientService.saveOrUpdate(p);
		List<Patient> p1 =patientService.getPatient();
		assertThat(p1).size().isGreaterThan(0);

		
		
		
	}
	
	@Test
	void deletePatientService()
	{
		Medicines med= new Medicines();
		med.setMedicineId(1);
		Disease d= new Disease();
		d.setDiseaseId(1);
		Doctor doc= new Doctor();
		doc.setDoctor_Id(1);
		
		Patient p = new Patient();
		p.setPatientId(1);
		
		p.setMedicationList(med);
		p.setDoctor(doc);
		p.setDisease(d);
		
		patientService.saveOrUpdate(p);
		
		patientService.delete(1);
		
		assertThat(patientrepo.existsById(1)).isFalse();

		
		
	}
	

}

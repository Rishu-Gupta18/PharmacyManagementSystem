package com.spring.Services;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.*;

import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.spring.model.Disease;
import com.spring.model.Doctor;
import com.spring.model.Medicines;
import com.spring.model.Patient;
import com.spring.repositories.PatientRepo;
import com.spring.services.PatientService;

import jakarta.transaction.Transactional;

@SpringBootTest
class PatientServicesTest {

	@Autowired
	private PatientRepo patientrepo;
	
	@Autowired
	private PatientService patientService;

	@Test
	@Transactional
	void CreatePatientService()
	{
		
		Medicines med= new Medicines();
		med.setMedicineId(1);
		List<Medicines> medicine= new ArrayList<Medicines>();
		medicine.add(med);

		
		Doctor doc= new Doctor();
		doc.setDoctor_Id(1);
		

	
		
		List<Doctor> doctor= new ArrayList<Doctor>();
		doctor.add(doc);
		
		Disease d= new Disease();
		d.setDiseaseId(1);
		

	
		
		
		
		
		Patient pat= new Patient();
		
		pat.setPatientId(1);
		pat.setPatientName("Rishu Gupta");
		pat.setDateOfAdmission("2022-03-23");
		pat.setDateOfDischarge("2022-03-25");
		pat.setMedicineCost(45);
		pat.setBillAmountPaid(450);
		pat.setAdmittedReason("Mental Issue");
		pat.setAddress("Pune");
		pat.setDoctor(doctor);
		pat.setMedicationList(medicine);
		pat.setDisease(d);
		
		assertEquals("Successfully Done", patientService.saveOrUpdate(pat));
		
	}
	
	@Test
	@Transactional
	void getPatientService()
	{
		Medicines med= new Medicines();
		med.setMedicineId(1);
		List<Medicines> medicine= new ArrayList<Medicines>();
		medicine.add(med);
		
		
		
		Doctor doc= new Doctor();
		doc.setDoctor_Id(1);
		

	
		
		List<Doctor> doctor= new ArrayList<Doctor>();
		doctor.add(doc);
		
		Disease d= new Disease();
		d.setDiseaseId(1);
		

	
		
		
		
		
		Patient pat= new Patient();
		
		pat.setPatientId(1);
		pat.setPatientName("Rishu Gupta");
		pat.setDateOfAdmission("2022-03-23");
		pat.setDateOfDischarge("2022-03-25");
		pat.setMedicineCost(45);
		pat.setBillAmountPaid(450);
		pat.setAdmittedReason("Mental Issue");
		pat.setAddress("Pune");
		pat.setDoctor(doctor);
		pat.setMedicationList(medicine);
		pat.setDisease(d);
		
		patientService.saveOrUpdate(pat);
		List<Patient> p1 =patientService.getPatient();
		assertThat(p1).size().isGreaterThan(0);

		
		
		
	}
	
	@Test
	@Transactional
	void deletePatientService()
	{
		Medicines med= new Medicines();
		med.setMedicineId(1);
		List<Medicines> medicine= new ArrayList<Medicines>();
		medicine.add(med);
		
		
		
		Doctor doc= new Doctor();
		doc.setDoctor_Id(1);
		

	
		
		List<Doctor> doctor= new ArrayList<Doctor>();
		doctor.add(doc);
		
		Disease d= new Disease();
		d.setDiseaseId(1);
		

	
		
		
		
		
		Patient pat= new Patient();
		
		pat.setPatientId(1);
		pat.setPatientName("Rishu Gupta");
		pat.setDateOfAdmission("2022-03-23");
		pat.setDateOfDischarge("2022-03-25");
		pat.setMedicineCost(45);
		pat.setBillAmountPaid(450);
		pat.setAdmittedReason("Mental Issue");
		pat.setAddress("Pune");
		pat.setDoctor(doctor);
		pat.setMedicationList(medicine);
		pat.setDisease(d);
		
		patientService.saveOrUpdate(pat);
		
		patientService.delete(1);
		
		assertThat(patientrepo.existsById(1)).isFalse();

		
		
	}
	

}

package com.spring.Repository;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.*;

import java.util.List;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.spring.model.Patient;
import com.spring.repositories.PatientRepo;
import com.spring.services.PatientService;

@SpringBootTest
class PatientRepoTest {

	@Autowired
	private PatientRepo patientrepo;
	
	@Autowired
	private PatientService patientService;
	
	@Test
	void create() {
		
		Patient pat= new Patient();
		
		pat.setPatientId(1);
		pat.setPatientName("Rishu Gupta");
		pat.setDateOfAdmission("2022-03-23");
		pat.setDateOfDischarge("2022-03-25");
		pat.setMedicineCost(45);
		pat.setBillAmountPaid(450);
		pat.setAdmittedReason("Mental Issue");
		pat.setAddress("Pune");
		
		
		

	
		
		patientrepo.save(pat);
		
		assertNotNull(patientrepo.findById(1).get());
		
	}
	
	@Test
	void singleData()
	{

		Patient pat1= patientrepo.findById(1).get();	
		assertEquals(1,pat1.getPatientId());
	}
	
	@Test
	void getData()
	{
		List<Patient> p = (List<Patient>) patientrepo.findAll();
		assertThat(p).size().isGreaterThan(0);
	}

	@Test
	void deleteData()
	{
		Patient pat= new Patient();
		pat.setPatientId(1);
		pat.setPatientName("Rishu Gupta");
		pat.setDateOfAdmission("2022-03-23");
		pat.setDateOfDischarge("2022-03-25");
		pat.setMedicineCost(45);
		pat.setBillAmountPaid(450);
		pat.setAdmittedReason("Mental Issue");
		pat.setAddress("Pune");
		patientrepo.save(pat);
		
		patientrepo.deleteById(1);
		
		assertThat(patientrepo.existsById(1)).isFalse();
		
		
		
	}
	 
	@Test
	public void update()
	{
		Patient pat= patientrepo.findById(1).get();		
		pat.setPatientName("Gaurav Gupta");
		
		patientrepo.save(pat);
		
		assertNotEquals("Rishu Gupta", pat.getPatientName());
		
	}
	

}

package ControllerTest;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyInt;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.Test;
import org.skyscreamer.jsonassert.JSONAssert;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.RequestBuilder;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.spring.controller.PatientController;
import com.spring.model.Disease;
import com.spring.model.Doctor;
import com.spring.model.Medicines;
import com.spring.model.Patient;
import com.spring.services.PatientService;

@WebMvcTest
@ContextConfiguration(classes= PatientController.class)
class PatientControllerTest {
	
	@Autowired
	private MockMvc mockMvc;
	
	@MockBean
	private PatientService patientService;
	
	@Autowired
	private ObjectMapper mapper = new ObjectMapper();

	@Test
	void patientSaveTest() throws Exception {
	
		//String requestBody = "{\"pateintId\" : \"1\", "+" \"patientName\":\"Rishu Gupta\" , " + "\"address\" : \"Pune\"}";
		
		Medicines med= new Medicines();
		med.setMedicineId(1);
		Disease d= new Disease();
		d.setDiseaseId(1);
		Doctor doc= new Doctor();
		doc.setDoctor_Id(1);
		
		Patient p= new Patient();
		p.setPatientId(1);
		p.setPatientName("Rishu Gupta");
		p.setAddress("Pune");
		p.setMedicationList(med);
		p.setDoctor(doc);
		p.setDisease(d);
		
//		when(patientService.saveOrUpdate(any(Patient.class))).thenReturn(Patient);
		when(patientService.saveOrUpdate(any(Patient.class))).thenReturn("Successfully Done");
		
		String json= mapper.writeValueAsString(p);
		
		RequestBuilder requestBuilder = MockMvcRequestBuilders
				.post("/patient")
				.content(json)
				.contentType(MediaType.APPLICATION_JSON);
		
		MvcResult mvcResult=mockMvc.perform(requestBuilder)
				.andExpect(status().isOk())
                .andReturn();
		
		String actualResponseBody = mvcResult.getResponse().getContentAsString();
		String expected="Successfully Done";
		assertThat(actualResponseBody).isEqualToIgnoringWhitespace(expected);
		
//		String response = mvcResult.getResponse().getContentAsString();
//		
//		System.out.println("Response as String" + response);
//		
//		JSONAssert.assertEquals("{patientId:1}", response, false);

	}
	@Test
	void patientGetTest() throws Exception {
	
		//String requestBody = "{\"pateintId\" : \"1\", "+" \"patientName\":\"Rishu Gupta\" , " + "\"address\" : \"Pune\"}";
		List<Patient> patient=new ArrayList<Patient>();
		Medicines med= new Medicines();
		med.setMedicineId(1);
		Disease d= new Disease();
		d.setDiseaseId(1);
		Doctor doc= new Doctor();
		doc.setDoctor_Id(1);
		
		Patient p= new Patient();
		p.setPatientId(1);
		p.setPatientName("Rishu Gupta");
		p.setAddress("Pune");
		p.setMedicationList(med);
		p.setDoctor(doc);
		p.setDisease(d);
		patient.add(p);
//		when(patientService.saveOrUpdate(any(Patient.class))).thenReturn(Patient);
		when(patientService.getPatient()).thenReturn(patient);
		
		String json= mapper.writeValueAsString(p);
		
		RequestBuilder requestBuilder = MockMvcRequestBuilders
				.get("/patient")
				.content(json)
				.contentType(MediaType.APPLICATION_JSON);
		MvcResult mvcResult=mockMvc.perform(requestBuilder)
				.andExpect(status().isOk())
                .andReturn();
		
		String response = mvcResult.getResponse().getContentAsString();

		JSONAssert.assertEquals("[{patientId:1}]", response, false);
		
	}
	@Test
	void patientDeleteTest() throws Exception {
	
		//String requestBody = "{\"pateintId\" : \"1\", "+" \"patientName\":\"Rishu Gupta\" , " + "\"address\" : \"Pune\"}";
		List<Patient> patient=new ArrayList<Patient>();
		Medicines med= new Medicines();
		med.setMedicineId(1);
		Disease d= new Disease();
		d.setDiseaseId(1);
		Doctor doc= new Doctor();
		doc.setDoctor_Id(1);
		
		Patient p= new Patient();
		p.setPatientId(1);
		p.setPatientName("Rishu Gupta");
		p.setAddress("Pune");
		p.setMedicationList(med);
		p.setDoctor(doc);
		p.setDisease(d);
		patient.add(p);
//		when(patientService.saveOrUpdate(any(Patient.class))).thenReturn(Patient);
		when(patientService.getPatient()).thenReturn(patient);
		
		String json= mapper.writeValueAsString(p);
		
		RequestBuilder requestBuilder = MockMvcRequestBuilders
				.delete("/patient/1")
				.content(json)
				.contentType(MediaType.APPLICATION_JSON);
		MvcResult mvcResult=mockMvc.perform(requestBuilder)
				.andExpect(status().isOk())
                .andReturn();
     
		String response = mvcResult.getResponse().getContentAsString();
		String expected="Sucessfully Deleted";
		assertThat(response).isEqualToIgnoringWhitespace(expected);

//		String response = mvcResult.getResponse().getContentAsString();
//
//		JSONAssert.assertEquals("[{patientId:1}]", response, true);
		
	}
	@Test
	void patientUpdateUserByIdTest() throws Exception {
	
		List<Patient> patient=new ArrayList<Patient>();
		Medicines med= new Medicines();
		med.setMedicineId(1);
		Disease d= new Disease();
		d.setDiseaseId(1);
		Doctor doc= new Doctor();
		doc.setDoctor_Id(1);
		
		Patient p= new Patient();
		p.setPatientId(1);
		p.setPatientName("Rishu Gupta");
		p.setAddress("Pune");
		p.setMedicationList(med);
		p.setDoctor(doc);
		p.setDisease(d);
		patient.add(p);
//		when(patientService.saveOrUpdate(any(Patient.class))).thenReturn(Patient);
		when(patientService.saveOrUpdate(any(Patient.class))).thenReturn("Sucessfully Done");
		
		String json= mapper.writeValueAsString(p);
		
		RequestBuilder requestBuilder = MockMvcRequestBuilders
				.put("/patient")
				.content(json)
				.contentType(MediaType.APPLICATION_JSON);
		MvcResult mvcResult=mockMvc.perform(requestBuilder)
				.andExpect(status().isOk())
                .andReturn();
		String response = mvcResult.getResponse().getContentAsString();
		String expected="Sucessfully Updated";
		assertThat(response).isEqualToIgnoringWhitespace(expected);

//		JSONAssert.assertEquals("{patientId:1}", response, false);

	}
}

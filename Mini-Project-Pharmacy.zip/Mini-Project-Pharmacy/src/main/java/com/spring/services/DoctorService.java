package com.spring.services;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.spring.model.Doctor;
import com.spring.model.Medicines;
import com.spring.model.Patient;
import com.spring.repositories.DoctorRepo;

@Service
public class DoctorService {
	
	@Autowired
	DoctorRepo doctorRepo;
	
	public List<Doctor> getDoctor() 
	{
	List<Doctor> doc = new ArrayList<Doctor>();
	doctorRepo.findAll().forEach(doc1 -> doc.add(doc1));
	return doc;
	}
	public Doctor getDoctorById(int id) 
	{
	return doctorRepo.findById(id).get();
	}

	public void saveOrUpdate(Doctor doctor) 
	{
		doctorRepo.save(doctor);
		
	}

	public void delete(int id) 
	{
		doctorRepo.deleteById(id);
	}

	public void update(Doctor doctor, int doctorId) 
	{
		doctorRepo.save(doctor);
	}
	
//	public void validateDoctor(Patient patient)
//	{
//		Optional<Doctor> doc=doctorRepo.findById(patient.getDoctor().getDoctor_Id());
//		if(!(doc.isEmpty()))
//		{
//			patient.setDoctor(doc.get());
//		}
//		
//	}
	public void validateDoctor(List<Doctor> doc)
	{
//	List<Doctor> docto= doc;
	for(int i=0 ; i<doc.size() ; i++)
	{
		Optional<Doctor> doctor= doctorRepo.findById(doc.get(i).getDoctor_Id());
		if(doctor.isEmpty())
		{
			System.out.println(doc.get(i));
			doctorRepo.save(doc.get(i));
		}
	}
	}


}

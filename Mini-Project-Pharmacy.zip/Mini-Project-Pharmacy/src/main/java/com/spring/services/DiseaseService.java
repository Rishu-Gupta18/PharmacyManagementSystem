package com.spring.services;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.spring.model.Disease;
import com.spring.model.Doctor;
import com.spring.model.Patient;
import com.spring.repositories.DiseaseRepo;





@Service
public class DiseaseService {
	
	@Autowired
	DiseaseRepo diseaseRepo;
	
	public List<Disease> getDisease() 
	{
	List<Disease> dis = new ArrayList<Disease>();
	diseaseRepo.findAll().forEach(dis1 -> dis.add(dis1));
	return dis;
	}
	
	public Disease getDiseaseById(int id) 
	{
	return diseaseRepo.findById(id).get();
	}

	public void saveOrUpdate(Disease disease) 
	{
		diseaseRepo.save(disease);
	}

	public void delete(int id) 
	{
		diseaseRepo.deleteById(id);
	}

	public void update(Disease disease, int diseaseId) 
	{
		diseaseRepo.save(disease);
	}
	
	public void validateDisease(Patient patient)
	{
		
		Optional<Disease> di=diseaseRepo.findById(patient.getDisease().getDiseaseId());
		if(di.isEmpty())
		{
//			patient.setDisease(di.get());
			diseaseRepo.save(patient.getDisease());
		}
		
	}
}

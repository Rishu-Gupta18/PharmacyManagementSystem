package com.spring.services;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.spring.model.Disease;
import com.spring.model.Doctor;
import com.spring.model.Medicines;
import com.spring.model.Patient;
import com.spring.repositories.MedicinesRepo;

@Service
public class MedicineService {
	
	@Autowired
	MedicinesRepo medicinesRepo;
	
	public List<Medicines> getMedicine() 
	{
	List<Medicines> med = new ArrayList<Medicines>();
	medicinesRepo.findAll().forEach(med1 -> med.add(med1));
	return med;
	}
	public Medicines getMedicineById(int id) 
	{
	return medicinesRepo.findById(id).get();
	}

	public void saveOrUpdate(Medicines medicine) 
	{
		medicinesRepo.save(medicine);
	}

	public void delete(int id) 
	{
		medicinesRepo.deleteById(id);
	}

	public void update(Medicines medicine, int medicineId) 
	{
		medicinesRepo.save(medicine);
	}
//	public void validateMedicines(Patient patient)
//	{
//		
//		Optional<Medicines> med=medicinesRepo.findById(patient.getMedicationList().getMedicineId());
//		if(!(med.isEmpty()))
//		{
//			patient.setMedicationList(med.get());
//		}
//		
//		
//	}
	public void validateMedicines(List<Medicines> medi)
	{
		List<Medicines> med= medi;
		for(int i=0 ; i<med.size() ; i++)
		{
			Optional<Medicines> medicine= medicinesRepo.findById(med.get(i).getMedicineId());
			if(medicine.isEmpty())
			{
				medicinesRepo.save(med.get(i));
			}
		}
	}
	

}

package com.spring.services;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.spring.model.Disease;
import com.spring.model.Doctor;
import com.spring.model.Medicines;
import com.spring.model.Patient;
import com.spring.repositories.DiseaseRepo;
import com.spring.repositories.DoctorRepo;
import com.spring.repositories.MedicinesRepo;
import com.spring.repositories.PatientRepo;

@Service
public class PatientService {
	@Autowired
	MedicinesRepo medicinerepo;
	
	@Autowired
	PatientRepo patientRepo;
	
	@Autowired
	DoctorRepo doctorRepo;
	
	@Autowired 
	DiseaseRepo diseaseRepo;
	
	@Autowired
	DoctorService doctorService;
	
	@Autowired
	DiseaseService diseaseService;
	
	@Autowired
	MedicineService medicineService;
	
	
	
	public List<Patient> getPatient() 
	{
	List<Patient> pat = new ArrayList<Patient>();
	patientRepo.findAll().forEach(pat1 -> pat.add(pat1));
	return pat;
	}
	
	public Patient getPatientById(int id) 
	{
	return patientRepo.findById(id).get();
	}

	public String saveOrUpdate(Patient patient) 
	{
		int result=0;
		long count= patientRepo.count();
		if(count<15) {
//		doctorService.validateDoctor(patient);// For validating the doctorID
		diseaseService.validateDisease(patient);// For validating the diseaseId
//		medicineService.validateMedicines(patient);// For validating the medicinesList
		doctorService.validateDoctor(patient.getDoctor());
		medicineService.validateMedicines(patient.getMedicationList());		
//		patient.setMedicineCost(patient.getMedicationList().getCost());// for getting the cost of medicines
	
		// for medication cost
		patientRepo.save(patient);
		
		
		//medicationlist cost
		List<Patient> p1=patientRepo.patientdata();
		for(int i=0;i<p1.size();i++) { //for getting the patient details
			if(p1.get(i).getPatientId()==patient.getPatientId()) {
				int  sum=0;
				// for getting the medication list in the patient entity
		         List<Medicines> m=p1.get(i).getMedicationList();
		         for(int j=0;j<m.size();j++) {
		        	 // setting the cost in the global variable
		        	sum+= m.get(j).getCost();
		        	result=sum;
		         }
		         }
		}
		Patient pat=patient;
		// and then save into the patient repository
		pat.setMedicineCost(result);
		patientRepo.save(pat);
	
		

		return "Successfully Done";
		
		}
		else {
			return "No of patient exceeded";
		}
	}

	private Medicines List(Optional<Medicines> medicines) {
		// TODO Auto-generated method stub
		return null;
	}

	public void delete(int id) 
	{
		patientRepo.deleteById(id);
		System.out.println("SuccessFully Deleted");
	}

	public void update(Patient patient, int patientId) 
	{
		patientRepo.save(patient);
	}



}

package com.spring.repositories;

import org.springframework.data.repository.CrudRepository;

import com.spring.model.Disease;

public interface DiseaseRepo extends CrudRepository<Disease, Integer> {

}

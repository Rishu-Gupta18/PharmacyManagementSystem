package com.spring.repositories;


import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.spring.model.Doctor;
import com.spring.model.Medicines;
import com.spring.model.Patient;



@Repository
public interface PatientRepo extends CrudRepository<Patient, Integer>{

	@Query(value="select * from Patient p",nativeQuery=true)
	List<Patient> patientdata();
   
//	@Query(value="Select * from Patient n",nativeQuery = true)
//	public List<Patient> patient();

}

package com.spring.repositories;


import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.spring.model.Doctor;
import com.spring.model.Patient;



@Repository
public interface PatientRepo extends CrudRepository<Patient, Integer>{


//	long countById(int patientId);
//	@Query("Select count(n) from Patient n")	
//	public Patient patientCount();
//	@Query(value = "SELECT count(id) FROM Patient where patientId = :patientId")
//	public Long count(int patientId);


}

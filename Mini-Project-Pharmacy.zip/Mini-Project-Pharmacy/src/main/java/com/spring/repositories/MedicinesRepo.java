package com.spring.repositories;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;

import com.spring.model.Medicines;

public interface MedicinesRepo extends CrudRepository<Medicines, Integer> {
	
//	@Query(value="Select * from Patient n",nativeQuery = true)
//	public List<Patient> patient();
	
}

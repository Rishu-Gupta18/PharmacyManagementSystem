package com.spring.repositories;

import org.springframework.data.repository.CrudRepository;

import com.spring.model.Medicines;

public interface MedicinesRepo extends CrudRepository<Medicines, Integer> {

}

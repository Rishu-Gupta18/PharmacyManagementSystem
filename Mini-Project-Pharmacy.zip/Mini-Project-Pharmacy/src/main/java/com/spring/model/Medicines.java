package com.spring.model;

import java.sql.Date;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;

@Entity
public class Medicines {
	
	private String medicineName;
	@Id
//	@GeneratedValue(strategy = GenerationType.AUTO)
	private int medicineId;
	private String yearOfManufacture;
	private String expiryDate;
	private int cost;
	private String manufacturedCompanyName;
	public String getMedicineName() {
		return medicineName;
	}
	public void setMedicineName(String medicineName) {
		this.medicineName = medicineName;
	}
	public int getMedicineId() {
		return medicineId;
	}
	public void setMedicineId(int medicineId) {
		this.medicineId = medicineId;
	}
	public String getYearOfManufacture() {
		return yearOfManufacture;
	}
	public void setYearOfManufacture(String yearOfManufacture) {
		this.yearOfManufacture = yearOfManufacture;
	}
	public String getExpiryDate() {
		return expiryDate;
	}
	public void setExpiryDate(String expiryDate) {
		this.expiryDate = expiryDate;
	}
	public int getCost() {
		return cost;
	}
	public void setCost(int cost) {
		this.cost = cost;
	}
	public String getManufacturedCompanyName() {
		return manufacturedCompanyName;
	}
	public void setManufacturedCompanyName(String manufacturedCompanyName) {
		this.manufacturedCompanyName = manufacturedCompanyName;
	}
	public Medicines(String medicineName, int medicineId, String yearOfManufacture, String expiryDate, int cost,
			String manufacturedCompanyName) {
		super();
		this.medicineName = medicineName;
		this.medicineId = medicineId;
		this.yearOfManufacture = yearOfManufacture;
		this.expiryDate = expiryDate;
		this.cost = cost;
		this.manufacturedCompanyName = manufacturedCompanyName;
	}
	public Medicines() {
		super();
		// TODO Auto-generated constructor stub
	}
	@Override
	public String toString() {
		return "Medicines [medicineName=" + medicineName + ", medicineId=" + medicineId + ", yearOfManufacture="
				+ yearOfManufacture + ", expiryDate=" + expiryDate + ", cost=" + cost + ", manufacturedCompanyName="
				+ manufacturedCompanyName + "]";
	}
	
	
}

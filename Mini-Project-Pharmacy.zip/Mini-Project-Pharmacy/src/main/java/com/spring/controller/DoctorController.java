package com.spring.controller;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.spring.model.Disease;
import com.spring.model.Doctor;
import com.spring.services.DoctorService;
@RestController
public class DoctorController {
	
	@Autowired
	DoctorService doctorService;
	
	@GetMapping("/doctor")
	public List<Doctor> getDoctors() 
	{
	return doctorService.getDoctor();
	}
	@GetMapping("/doctor/{doctorId}")
	private Doctor getDoctors(@PathVariable("doctorId") int doctorId) 
	{
	return doctorService.getDoctorById(doctorId);
	}
	
	
	@DeleteMapping("/doctor/{doctorId}")
	private String deleteDoctor(@PathVariable("doctorId") int doctorId) 
	{
		doctorService.delete(doctorId);
		return "Sucessfully Deleted";

	}

	@PostMapping("/doctor")
	private String saveDoctor(@RequestBody Doctor doctor) 
	{
		doctorService.saveOrUpdate(doctor);
		return "Sucessfully Done";

	}
	
	@PutMapping("/doctor")
	private String update(@RequestBody Doctor doctor) 
	{
		doctorService.saveOrUpdate(doctor);
		return "Sucessfully Updated";
	}
}

package com.spring.model;

import java.sql.Date;
import java.util.Set;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.OneToMany;
import jakarta.persistence.OneToOne;

@Entity
public class Patient {
	
			@Id
		//	@GeneratedValue(strategy = GenerationType.AUTO)
			private Integer patientId;
			private String patientName;
		
			private Date dateOfAdmission;
			private Date dateOfDischarge;
			
			private int billAmountPaid;
			private String admittedReason;
			private String address;
			
			//for medication cost
			//@OneToOne(cascade = CascadeType.ALL)
			//private Medicines medicines;
			
			
			//for diseaseId
			@OneToOne(cascade = CascadeType.ALL)
//			private int diseaseId;
			private Disease disease;
			
			//for medicationlist
			@OneToMany(cascade = CascadeType.ALL)
			private Set <Medicines> medicationList;
			
			@OneToOne(cascade = CascadeType.ALL)
			//@JoinColumn(name = "doctor_doctor_Id")
			private Doctor doctor;

			

			public Patient(Integer patientId, String patientName, Date dateOfAdmission, Date dateOfDischarge,
					int billAmountPaid, String admittedReason, String address, Disease disease,
					Set<Medicines> medicationList, Doctor doctor) {
				super();
				this.patientId = patientId;
				this.patientName = patientName;
				this.dateOfAdmission = dateOfAdmission;
				this.dateOfDischarge = dateOfDischarge;
				this.billAmountPaid = billAmountPaid;
				this.admittedReason = admittedReason;
				this.address = address;
				this.disease = disease;
				this.medicationList = medicationList;
				this.doctor = doctor;
			}



			public Integer getPatientId() {
				return patientId;
			}



			public void setPatientId(Integer patientId) {
				this.patientId = patientId;
			}



			public String getPatientName() {
				return patientName;
			}



			public void setPatientName(String patientName) {
				this.patientName = patientName;
			}



			public Date getDateOfAdmission() {
				return dateOfAdmission;
			}



			public void setDateOfAdmission(Date dateOfAdmission) {
				this.dateOfAdmission = dateOfAdmission;
			}



			public Date getDateOfDischarge() {
				return dateOfDischarge;
			}



			public void setDateOfDischarge(Date dateOfDischarge) {
				this.dateOfDischarge = dateOfDischarge;
			}



			public int getBillAmountPaid() {
				return billAmountPaid;
			}



			public void setBillAmountPaid(int billAmountPaid) {
				this.billAmountPaid = billAmountPaid;
			}



			public String getAdmittedReason() {
				return admittedReason;
			}



			public void setAdmittedReason(String admittedReason) {
				this.admittedReason = admittedReason;
			}



			public String getAddress() {
				return address;
			}



			public void setAddress(String address) {
				this.address = address;
			}



			public Disease getDisease() {
				return disease;
			}



			public void setDisease(Disease disease) {
				this.disease = disease;
			}



			public Set<Medicines> getMedicationList() {
				return medicationList;
			}



			public void setMedicationList(Set<Medicines> medicationList) {
				this.medicationList = medicationList;
			}



			public Doctor getDoctor() {
				return doctor;
			}



			public void setDoctor(Doctor doctor) {
				this.doctor = doctor;
			}



			public Patient() {
				super();
				// TODO Auto-generated constructor stub
			}
			
			
			
			


}

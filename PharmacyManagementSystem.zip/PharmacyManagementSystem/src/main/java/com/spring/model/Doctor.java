package com.spring.model;

import java.util.Set;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.OneToMany;
import jakarta.persistence.OneToOne;

@Entity

public class Doctor {
	
	private String doctorName;
	@Id
	//@GeneratedValue(strategy = GenerationType.AUTO)
	private Integer doctor_Id;
	private String designation;
	private String address;
	private String specialization;
	
	@OneToMany(cascade = CascadeType.ALL)
	private Set<Patient> patientsAssigned;
	

	public int getDoctor_Id() {
		return doctor_Id;
	}
	public void setDoctor_Id(int doctor_Id) {
		this.doctor_Id = doctor_Id;
	}

	public String getDoctorName() {
		return doctorName;
	}
	public void setDoctorName(String doctorName) {
		this.doctorName = doctorName;
	}
	public int getDoctorId() {
		return doctor_Id;
	}
	public void setDoctorId(int doctorId) {
		this.doctor_Id = doctorId;
	}
	public String getDesignation() {
		return designation;
	}
	public void setDesignation(String designation) {
		this.designation = designation;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getSpecialization() {
		return specialization;
	}
	public void setSpecialization(String specialization) {
		this.specialization = specialization;
	}
	public Set<Patient> getPatientsAssigned() {
		return patientsAssigned;
	}
	public void setPatientsAssigned(Set<Patient> patientsAssigned) {
		this.patientsAssigned = patientsAssigned;
	}
	public Doctor(String doctorName, int doctor_Id, String designation, String address, String specialization,
			Set<Patient> patientsAssigned) {
		super();
		this.doctorName = doctorName;
		this.doctor_Id = doctor_Id;
		this.designation = designation;
		this.address = address;
		this.specialization = specialization;
		this.patientsAssigned = patientsAssigned;
	}
	public Doctor() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	

}

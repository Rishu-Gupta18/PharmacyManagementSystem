package com.spring.model;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;

@Entity
public class Disease {
	
	@Id
	//@GeneratedValue(strategy = GenerationType.AUTO)
	private int diseaseId;
	private String diseaseName;
	
	private String medicationSuggested;
	
	public String getDiseaseName() {
		return diseaseName;
	}
	public void setDiseaseName(String diseaseName) {
		this.diseaseName = diseaseName;
	}
	public int getDiseaseId() {
		return diseaseId;
	}
	public void setDiseaseId(int diseaseId) {
		this.diseaseId = diseaseId;
	}
	public String getMedicationSuggested() {
		return medicationSuggested;
	}
	public void setMedicationSuggested(String medicationSuggested) {
		this.medicationSuggested = medicationSuggested;
	}
	public Disease(String diseaseName, int diseaseId, String medicationSuggested) {
		super();
		this.diseaseName = diseaseName;
		this.diseaseId = diseaseId;
		this.medicationSuggested = medicationSuggested;
	}
	public Disease() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	

}

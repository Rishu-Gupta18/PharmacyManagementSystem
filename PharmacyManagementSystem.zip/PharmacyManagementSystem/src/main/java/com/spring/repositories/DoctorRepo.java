package com.spring.repositories;

import org.springframework.data.repository.CrudRepository;

import com.spring.model.Doctor;

public interface DoctorRepo extends CrudRepository<Doctor, Integer> {

}

package com.spring.repositories;

import org.springframework.data.jdbc.repository.query.Query;
import org.springframework.data.repository.CrudRepository;

import com.spring.model.Doctor;
import com.spring.model.Patient;




public interface PatientRepo extends CrudRepository<Patient, Integer>{
//	@Query("select s from Doctor s where doctor_Id= :doctorId")
//	public Doctor getDoctor(String doctor_ID);
	
//	@Query("select d from Doctor d where doctor_ID= :doctor_ID and doctorName= :doctorName")
//	public Doctor FindDoctor(int doctor_ID,String doctorName);



}

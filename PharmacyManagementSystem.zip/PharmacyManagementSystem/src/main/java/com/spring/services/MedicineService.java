package com.spring.services;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.spring.model.Disease;
import com.spring.model.Medicines;
import com.spring.repositories.MedicinesRepo;

@Service
public class MedicineService {
	
	@Autowired
	MedicinesRepo medicinesRepo;
	
	public List<Medicines> getMedicine() 
	{
	List<Medicines> med = new ArrayList<Medicines>();
	medicinesRepo.findAll().forEach(med1 -> med.add(med1));
	return med;
	}
	public Medicines getMedicineById(int id) 
	{
	return medicinesRepo.findById(id).get();
	}

	public void saveOrUpdate(Medicines medicine) 
	{
		medicinesRepo.save(medicine);
	}

	public void delete(int id) 
	{
		medicinesRepo.deleteById(id);
	}

	public void update(Medicines medicine, int medicineId) 
	{
		medicinesRepo.save(medicine);
	}

}

package com.spring.services;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.spring.model.Doctor;
import com.spring.model.Medicines;
import com.spring.model.Patient;
import com.spring.repositories.PatientRepo;

@Service
public class PatientService {
	
	@Autowired
	PatientRepo patientRepo;
	
	public List<Patient> getPatient() 
	{
	List<Patient> pat = new ArrayList<Patient>();
	patientRepo.findAll().forEach(pat1 -> pat.add(pat1));
	return pat;
	}
	
	public Patient getPatientById(int id) 
	{
	return patientRepo.findById(id).get();
	}

	public void saveOrUpdate(Patient patient) 
	{
//		Doctor doc=patientRepo.FindDoctor(patient.getDoctor().getDoctor_Id(),patient.getDoctor().getDoctorName());
//		if(doc==null) 
//		{
//			patientRepo.save(patient);
//		}
//		else 
//		{
//			patient.setDoctor(doc);
//		    patientRepo.save(patient);
//		}
		
		patientRepo.save(patient);
	}

	public void delete(int id) 
	{
		patientRepo.deleteById(id);
	}

	public void update(Patient patient, int patientId) 
	{
		patientRepo.save(patient);
	}



}

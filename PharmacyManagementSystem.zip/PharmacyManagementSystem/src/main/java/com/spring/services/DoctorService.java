package com.spring.services;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.spring.model.Doctor;
import com.spring.model.Medicines;
import com.spring.model.Patient;
import com.spring.repositories.DoctorRepo;

@Service
public class DoctorService {
	
	@Autowired
	DoctorRepo doctorRepo;
	
	public List<Doctor> getDoctor() 
	{
	List<Doctor> doc = new ArrayList<Doctor>();
	doctorRepo.findAll().forEach(doc1 -> doc.add(doc1));
	return doc;
	}
	public Doctor getDoctorById(int id) 
	{
	return doctorRepo.findById(id).get();
	}

	public void saveOrUpdate(Doctor doctor) 
	{
		doctorRepo.save(doctor);
		
	}

	public void delete(int id) 
	{
		doctorRepo.deleteById(id);
	}

	public void update(Doctor doctor, int doctorId) 
	{
		doctorRepo.save(doctor);
	}
	

}

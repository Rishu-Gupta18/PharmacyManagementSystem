package com.spring.controller;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.spring.model.Disease;
import com.spring.model.Doctor;
import com.spring.services.DoctorService;
@RestController
public class DoctorController {
	
	@Autowired
	DoctorService doctorService;
	
	@GetMapping("/doctor")
	public List<Doctor> getDoctors() 
	{
	return doctorService.getDoctor();
	}
	@GetMapping("/doctor/{doctorId}")
	private Doctor getDoctors(@PathVariable("doctorId") int doctorId) 
	{
	return doctorService.getDoctorById(doctorId);
	}
	
	
	@DeleteMapping("/doctor/{doctorId}")
	private void deleteDoctor(@PathVariable("doctorId") int doctorId) 
	{
		doctorService.delete(doctorId);
	}

	@PostMapping("/doctor")
	private int saveDoctor(@RequestBody Doctor doctor) 
	{
		doctorService.saveOrUpdate(doctor);
		return doctor.getDoctorId();
	}
	
	@PutMapping("/doctor")
	private Doctor update(@RequestBody Doctor doctor) 
	{
		doctorService.saveOrUpdate(doctor);
	    return doctor;
	}
}
